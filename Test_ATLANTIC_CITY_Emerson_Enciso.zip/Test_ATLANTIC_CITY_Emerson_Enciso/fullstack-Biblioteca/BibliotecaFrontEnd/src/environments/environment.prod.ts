export const environment = {
  production: true,
  // apiUrl: 'http://localhost:4000'
  // https://localhost:7060/swagger/index.html
  apiUrl: 'https://localhost:7060'
};
