﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using BibliotecaWebAPI.Authorization;
using BibliotecaWebAPI.Helpers;
using BibliotecaWebAPI.Services;
using BibliotecaWebAPI.Entities;

namespace BibliotecaWebAPI.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class PrestamosController : ControllerBase
    {
        private readonly IPrestamoService _prestamoService;
        private readonly IMapper _mapper;
        private readonly ILogger<PrestamosController> _logger;

        public PrestamosController(
            IPrestamoService prestamoService,
            IMapper mapper,
            ILogger<PrestamosController> logger)
        {
            _prestamoService = prestamoService;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpPost("registrar")]
        public IActionResult RegistrarPrestamo(RegistrarPrestamoRequest model)
        {
            try
            {
                var prestamo = _prestamoService.RegistrarPrestamo(model);
                return Ok(new
                {
                    message = "Préstamo registrado exitosamente",
                    prestamoId = prestamo.Id
                });
            }
            catch (AppException ex)
            {
                _logger.LogError(ex, "Error al registrar préstamo");
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error inesperado al registrar préstamo");
                return StatusCode(500, new { message = "Ocurrió un error interno" });
            }
        }

        [HttpGet("cliente/{clienteId}")]
        public IActionResult ObtenerPrestamosPorCliente(int clienteId)
        {
            var prestamos = _prestamoService.ObtenerPrestamosPorCliente(clienteId);
            return Ok(prestamos);
        }

        [HttpGet("{id}")]
        public IActionResult ObtenerPrestamoPorId(int id)
        {
            var prestamo = _prestamoService.ObtenerPrestamoPorId(id);
            return Ok(prestamo);
        }

        [HttpPut("devolver/{id}")]
        public IActionResult RegistrarDevolucion(int id, RegistrarDevolucionRequest model)
        {
            try
            {
                _prestamoService.RegistrarDevolucion(id, model);
                return Ok(new { message = "Devolución registrada exitosamente" });
            }
            catch (AppException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}