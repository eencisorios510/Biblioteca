﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BibliotecaWebAPI.Migrations.SqlServerMigrations
{
    public partial class migration220420253 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CHK_DetalleReserva_Item",
                table: "DetalleReservas");

            migrationBuilder.DropCheckConstraint(
                name: "CHK_DetalleReserva_TipoItem",
                table: "DetalleReservas");

            migrationBuilder.AddCheckConstraint(
                name: "CHK_DetalleReserva_Item",
                table: "DetalleReservas",
                sql: "([TipoItem] = 'libro' AND [LibroId] IS NOT NULL AND [ProductoId] IS NULL) OR ([TipoItem] = 'producto' AND [ProductoId] IS NOT NULL AND [LibroId] IS NULL)");

            migrationBuilder.AddCheckConstraint(
                name: "CHK_DetalleReserva_TipoItem",
                table: "DetalleReservas",
                sql: "[TipoItem] IN ('libro', 'producto')");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CHK_DetalleReserva_Item",
                table: "DetalleReservas");

            migrationBuilder.DropCheckConstraint(
                name: "CHK_DetalleReserva_TipoItem",
                table: "DetalleReservas");

            migrationBuilder.AddCheckConstraint(
                name: "CHK_DetalleReserva_Item",
                table: "DetalleReservas",
                sql: "([tipo_item] = 'libro' AND [libro_id] IS NOT NULL AND [producto_id] IS NULL) OR ([tipo_item] = 'producto' AND [producto_id] IS NOT NULL AND [libro_id] IS NULL)");

            migrationBuilder.AddCheckConstraint(
                name: "CHK_DetalleReserva_TipoItem",
                table: "DetalleReservas",
                sql: "[tipo_item] IN ('libro', 'producto')");
        }
    }
}
