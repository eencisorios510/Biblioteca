﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BibliotecaWebAPI.Migrations.SqlServerMigrations
{
    public partial class migration220420252 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
