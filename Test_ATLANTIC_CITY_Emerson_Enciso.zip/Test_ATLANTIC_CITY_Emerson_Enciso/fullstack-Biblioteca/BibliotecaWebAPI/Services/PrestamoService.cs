﻿using AutoMapper;
using BibliotecaWebAPI.Authorization;
using BibliotecaWebAPI.Entities;
using BibliotecaWebAPI.Helpers;
using Microsoft.EntityFrameworkCore;

namespace BibliotecaWebAPI.Services
{
    public interface IPrestamoService
    {
        Prestamo RegistrarPrestamo(RegistrarPrestamoRequest model);
        IEnumerable<Prestamo> ObtenerPrestamosPorCliente(int clienteId);
        Prestamo ObtenerPrestamoPorId(int id);
        void RegistrarDevolucion(int id, RegistrarDevolucionRequest model);
    }

    public class PrestamoService : IPrestamoService
    {
        private readonly DataContext _context;
        private readonly IMapper _mapper;
        private readonly ILibroService _libroService;

        public PrestamoService(
            DataContext context,
            IMapper mapper,
            ILibroService libroService)
        {
            _context = context;
            _mapper = mapper;
            _libroService = libroService;
        }

        public Prestamo RegistrarPrestamo(RegistrarPrestamoRequest model)
        {
            // Validar que el cliente existe y no está en lista negra
            var cliente = _context.Clientes.Find(model.ClienteId);
            if (cliente == null)
                throw new AppException("Cliente no encontrado");

            if (cliente.EnListaNegra)
                throw new AppException("El cliente está en la lista negra y no puede realizar préstamos");


            // Validar disponibilidad de cada libro
            foreach (var detalle in model.Detalles)
            {
                if (!_libroService.ValidarDisponibilidad(detalle.EjemplarId))
                    throw new AppException($"El ejemplar con ID {detalle.EjemplarId} no está disponible");
            }

            // Crear el préstamo
            var prestamo = _mapper.Map<Prestamo>(model);
            prestamo.FechaPrestamo = DateTime.UtcNow;
            prestamo.Estado = "Activo";

            // Actualizar estado de los ejemplares
            foreach (var detalle in model.Detalles)
            {
                var ejemplar = _context.Ejemplares.Find(detalle.EjemplarId);
                if (ejemplar != null)
                {
                    ejemplar.Estado = "Prestado";
                    _context.Ejemplares.Update(ejemplar);
                }

                prestamo.Detalles.Add(new DetallePrestamo
                {
                    EjemplarId = detalle.EjemplarId,
                    DiasPrestamo = detalle.DiasPrestamo,
                    FechaDevolucionEstimada = DateTime.UtcNow.AddDays(detalle.DiasPrestamo)
                });
            }

            _context.Prestamos.Add(prestamo);
            _context.SaveChanges();

            return prestamo;
        }

        public IEnumerable<Prestamo> ObtenerPrestamosPorCliente(int clienteId)
        {
            return _context.Prestamos
                .Include(p => p.Detalles)
                .ThenInclude(d => d.Ejemplar)
                .ThenInclude(e => e.Libro)
                .Where(p => p.ClienteId == clienteId)
                .ToList();
        }

        public Prestamo ObtenerPrestamoPorId(int id)
        {
            var prestamo = _context.Prestamos
                .Include(p => p.Detalles)
                .ThenInclude(d => d.Ejemplar)
                .ThenInclude(e => e.Libro)
                .FirstOrDefault(p => p.Id == id);

            if (prestamo == null)
                throw new KeyNotFoundException("Préstamo no encontrado");

            return prestamo;
        }

        public void RegistrarDevolucion(int id, RegistrarDevolucionRequest model)
        {
            var prestamo = _context.Prestamos
                .Include(p => p.Detalles)
                .FirstOrDefault(p => p.Id == id);

            if (prestamo == null)
                throw new KeyNotFoundException("Préstamo no encontrado");

            if (prestamo.Estado == "Devuelto")
                throw new AppException("El préstamo ya fue devuelto");

            // Actualizar estado del préstamo
            prestamo.Estado = "Devuelto";

            // Actualizar estado de los ejemplares
            foreach (var detalle in prestamo.Detalles)
            {
                var ejemplar = _context.Ejemplares.Find(detalle.EjemplarId);
                if (ejemplar != null)
                {
                    ejemplar.Estado = "Disponible";
                    _context.Ejemplares.Update(ejemplar);
                }

                // Calcular penalidad si hay retraso
                if (model.FechaDevolucion > detalle.FechaDevolucionEstimada)
                {
                    var diasRetraso = (model.FechaDevolucion - detalle.FechaDevolucionEstimada).Days;
                    detalle.Penalidad = diasRetraso * 5; // $5 por día de retraso
                }
            }

            _context.Prestamos.Update(prestamo);
            _context.SaveChanges();
        }
    }
}