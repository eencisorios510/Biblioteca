﻿using BibliotecaWebAPI.Helpers;

namespace BibliotecaWebAPI.Services
{
    public interface ILibroService
    {
        bool ValidarDisponibilidad(int ejemplarId);
    }

    public class LibroService : ILibroService
    {
        private readonly DataContext _context;

        public LibroService(DataContext context)
        {
            _context = context;
        }

        public bool ValidarDisponibilidad(int ejemplarId)
        {
            var ejemplar = _context.Ejemplares.Find(ejemplarId);
            return ejemplar != null && ejemplar.Estado == "Disponible";
        }
    }
}