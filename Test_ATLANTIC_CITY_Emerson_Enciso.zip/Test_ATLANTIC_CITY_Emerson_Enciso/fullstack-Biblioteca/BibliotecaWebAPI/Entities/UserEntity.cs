﻿

using System.Text.Json.Serialization;
namespace BibliotecaWebAPI.Entities
{
    public class UserEntity
    {
        public int Id { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string Username { get; set; }

        [JsonIgnore]
        public string PasswordHash { get; set; }
    }
    public class RegistrarPrestamoRequest
    {
        public int ClienteId { get; set; }
        public List<DetallePrestamoRequest> Detalles { get; set; }
    }

    public class DetallePrestamoRequest
    {
        public int EjemplarId { get; set; }
        public int DiasPrestamo { get; set; }
    }
    public class RegistrarDevolucionRequest
    {
        public DateTime FechaDevolucion { get; set; }
    }

    public class Auditoria
    {
        public int Id { get; set; }
        public int UsuarioId { get; set; }
        public string Accion { get; set; }
        public string EntidadAfectada { get; set; }
        public int? IdEntidad { get; set; }
        public DateTime FechaHora { get; set; } = DateTime.UtcNow;
        public string DatosAnteriores { get; set; }
        public string DatosNuevos { get; set; }

        public Usuario Usuario { get; set; }
    }

    public class Categoria
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Tipo { get; set; } // 'libro' o 'producto'

        public ICollection<Libro> Libros { get; set; }
        public ICollection<Producto> Productos { get; set; }
    }

    public class Cliente
    {
        public int Id { get; set; }
        public int? UsuarioId { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string DocumentoIdentidad { get; set; }
        public string Direccion { get; set; }
        public int? UbigeoId { get; set; }
        public bool EnListaNegra { get; set; } = false;
        public string MotivoListaNegra { get; set; }
        public DateTime FechaRegistro { get; set; } = DateTime.UtcNow;

        public Usuario Usuario { get; set; }
        public Ubigeo Ubigeo { get; set; }
        public ICollection<Reserva> Reservas { get; set; }
        public ICollection<Transaccion> Transacciones { get; set; }
        public ICollection<Notificacion> Notificaciones { get; set; }
    }

    public class DetalleReserva
    {
        public int Id { get; set; }
        public int ReservaId { get; set; }
        public int? LibroId { get; set; }
        public int? ProductoId { get; set; }
        public string TipoItem { get; set; }
        public int Cantidad { get; set; } = 1;

        public Reserva Reserva { get; set; }
        public Libro Libro { get; set; }
        public Producto Producto { get; set; }
    }

    public class DetalleTransaccion
    {
        public int Id { get; set; }
        public int TransaccionId { get; set; }
        public int? EjemplarId { get; set; }
        public int? ProductoId { get; set; }
        public string TipoItem { get; set; }
        public int Cantidad { get; set; } = 1;
        public decimal PrecioUnitario { get; set; }
        public decimal Subtotal { get; set; }
        public int? DiasAlquiler { get; set; }
        public DateTime? FechaDevolucion { get; set; }
        public bool Devuelto { get; set; } = false;
        public decimal Penalidad { get; set; } = 0;

        public Transaccion Transaccion { get; set; }
        public Ejemplar Ejemplar { get; set; }
        public Producto Producto { get; set; }
    }

    public class Ejemplar
    {
        public int Id { get; set; }
        public int LibroId { get; set; }
        public string CodigoBarras { get; set; }
        public string CodigoQr { get; set; }
        public int? EstanteId { get; set; }
        public string Estado { get; set; } = "disponible";
        public DateTime? FechaAdquisicion { get; set; }
        public decimal? CostoAdquisicion { get; set; }

        public Libro Libro { get; set; }
        public Estante Estante { get; set; }
        public ICollection<DetalleTransaccion> DetalleTransacciones { get; set; }
    }

    public class Estante
    {
        public int Id { get; set; }
        public string Codigo { get; set; }
        public string Ubicacion { get; set; }
        public string Descripcion { get; set; }

        public ICollection<Ejemplar> Ejemplares { get; set; }
    }

    public class Libro
    {
        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string Editorial { get; set; }
        public int? AñoPublicacion { get; set; }
        public string Isbn { get; set; }
        public int CategoriaId { get; set; }
        public string Descripcion { get; set; }
        public decimal? PrecioVenta { get; set; }
        public decimal? PrecioAlquilerDiario { get; set; }
        public string Estado { get; set; } = "disponible";

        public Categoria Categoria { get; set; }
        public ICollection<Ejemplar> Ejemplares { get; set; }
        public ICollection<DetalleReserva> DetalleReservas { get; set; }
    }

    public class Notificacion
    {
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public string Titulo { get; set; }
        public string Mensaje { get; set; }
        public DateTime FechaEnvio { get; set; } = DateTime.UtcNow;
        public bool Leida { get; set; } = false;
        public string Tipo { get; set; }

        public Cliente Cliente { get; set; }
    }

    public class Perfil
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Permisos { get; set; }

        public ICollection<Usuario> Usuarios { get; set; }
    }

    public class Producto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public decimal Precio { get; set; }
        public int Stock { get; set; } = 0;
        public int CategoriaId { get; set; }

        public Categoria Categoria { get; set; }
        public ICollection<DetalleReserva> DetalleReservas { get; set; }
        public ICollection<DetalleTransaccion> DetalleTransacciones { get; set; }
    }

    public class Reserva
    {
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public DateTime FechaSolicitud { get; set; } = DateTime.UtcNow;
        public DateTime? FechaAprobacion { get; set; }
        public string Estado { get; set; } = "pendiente";
        public string Tipo { get; set; }
        public int? UsuarioAprobadorId { get; set; }

        public Cliente Cliente { get; set; }
        public Usuario UsuarioAprobador { get; set; }
        public ICollection<DetalleReserva> Detalles { get; set; }
    }

    public class Transaccion
    {
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public int UsuarioId { get; set; }
        public DateTime FechaHora { get; set; } = DateTime.UtcNow;
        public string Tipo { get; set; }
        public string Estado { get; set; } = "pendiente";
        public decimal MontoTotal { get; set; }
        public int MetodoPagoId { get; set; }
        public string DireccionEntrega { get; set; }
        public int? AgenciaDeliveryId { get; set; }
        public string CodigoSeguimiento { get; set; }
        public string Agencia { get; set; }
        public string MetodoPago { get; set; }

        public Cliente Cliente { get; set; }
        public Usuario Usuario { get; set; }
        public ICollection<DetalleTransaccion> Detalles { get; set; }
    }

    public class Ubigeo
    {
        public int Id { get; set; }
        public string Codigo { get; set; }
        public string Departamento { get; set; }
        public string Provincia { get; set; }
        public string Distrito { get; set; }
        public string Lugar { get; set; }

        public ICollection<Cliente> Clientes { get; set; }
    }

    public class Usuario
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string ContraseñaHash { get; set; }
        public string Telefono { get; set; }
        public bool TelefonoVerificado { get; set; } = false;
        public DateTime FechaRegistro { get; set; } = DateTime.UtcNow;
        public DateTime? UltimoAcceso { get; set; }
        public string Estado { get; set; } = "activo";
        public int PerfilId { get; set; }

        public Perfil Perfil { get; set; }
        public Cliente Cliente { get; set; }
        public ICollection<Auditoria> Auditorias { get; set; }
        public ICollection<Reserva> ReservasAprobadas { get; set; }
        public ICollection<Transaccion> Transacciones { get; set; }
    }
    public class Prestamo
    {
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public DateTime FechaPrestamo { get; set; } = DateTime.UtcNow;
        public string Estado { get; set; } = "Activo";
        public int? TransaccionId { get; set; }

        // Propiedades de navegación
        public Cliente Cliente { get; set; }
        public Transaccion Transaccion { get; set; }
        public ICollection<DetallePrestamo> Detalles { get; set; }
    }

    public class DetallePrestamo
    {
        public int Id { get; set; }
        public int PrestamoId { get; set; }
        public int EjemplarId { get; set; }
        public int DiasPrestamo { get; set; }
        public DateTime FechaDevolucionEstimada { get; set; }
        public DateTime? FechaDevolucionReal { get; set; }
        public bool Devuelto { get; set; } = false;
        public decimal Penalidad { get; set; } = 0;
        public string Estado { get; set; } = "Prestado"; // Prestado, Devuelto, Vencido

        // Propiedades de navegación
        public Prestamo Prestamo { get; set; }
        public Ejemplar Ejemplar { get; set; }
    }
}
