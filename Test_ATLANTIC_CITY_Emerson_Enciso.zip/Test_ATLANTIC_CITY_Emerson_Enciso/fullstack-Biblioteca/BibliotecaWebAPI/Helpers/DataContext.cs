﻿using Microsoft.EntityFrameworkCore;
namespace BibliotecaWebAPI.Helpers;

using BibliotecaWebAPI.Entities;

public class DataContext : DbContext
{
    protected readonly IConfiguration Configuration;

    public DataContext(IConfiguration configuration)
    {
        Configuration = configuration;
    }

    protected override void OnConfiguring(DbContextOptionsBuilder options)
    {
        // connect to sql server database
        options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
    }

    public DbSet<UserEntity> Users { get; set; }
    // Tablas principales
    public DbSet<Auditoria> Auditorias { get; set; }
    public DbSet<Categoria> Categorias { get; set; }
    public DbSet<Cliente> Clientes { get; set; }
    public DbSet<Ejemplar> Ejemplares { get; set; }
    public DbSet<Estante> Estantes { get; set; }
    public DbSet<Libro> Libros { get; set; }
    public DbSet<Notificacion> Notificaciones { get; set; }
    public DbSet<Perfil> Perfiles { get; set; }
    public DbSet<Producto> Productos { get; set; }
    public DbSet<Reserva> Reservas { get; set; }
    public DbSet<Transaccion> Transacciones { get; set; }
    public DbSet<Ubigeo> Ubigeos { get; set; }
    public DbSet<DetalleReserva> DetalleReservas { get; set; }
    public DbSet<DetalleTransaccion> DetalleTransacciones { get; set; }
    public DbSet<Prestamo> Prestamos { get; set; }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Configuraciones de las entidades


        // Cliente
        modelBuilder.Entity<Cliente>()
            .HasIndex(c => c.DocumentoIdentidad)
            .IsUnique();

        modelBuilder.Entity<Cliente>()
            .Property(c => c.EnListaNegra)
            .HasDefaultValue(false);

        modelBuilder.Entity<Cliente>()
            .Property(c => c.FechaRegistro)
            .HasDefaultValueSql("GETDATE()");

        // Libro
        modelBuilder.Entity<Libro>()
            .HasIndex(l => l.Isbn)
            .IsUnique();

        modelBuilder.Entity<Libro>()
            .Property(l => l.Estado)
            .HasDefaultValue("disponible");

        // Ejemplar
        modelBuilder.Entity<Ejemplar>()
            .HasIndex(e => e.CodigoBarras)
            .IsUnique();

        modelBuilder.Entity<Ejemplar>()
            .HasIndex(e => e.CodigoQr)
            .IsUnique();

        modelBuilder.Entity<Ejemplar>()
            .Property(e => e.Estado)
            .HasDefaultValue("disponible");

        // Reserva
        modelBuilder.Entity<Reserva>()
            .Property(r => r.FechaSolicitud)
            .HasDefaultValueSql("GETDATE()");

        modelBuilder.Entity<Reserva>()
            .Property(r => r.Estado)
            .HasDefaultValue("pendiente");

        // Transacción
        modelBuilder.Entity<Transaccion>()
            .Property(t => t.FechaHora)
            .HasDefaultValueSql("GETDATE()");

        modelBuilder.Entity<Transaccion>()
            .Property(t => t.Estado)
            .HasDefaultValue("pendiente");

        // DetalleTransaccion
        modelBuilder.Entity<DetalleTransaccion>()
            .Property(dt => dt.Cantidad)
            .HasDefaultValue(1);

        modelBuilder.Entity<DetalleTransaccion>()
            .Property(dt => dt.Devuelto)
            .HasDefaultValue(false);

        modelBuilder.Entity<DetalleTransaccion>()
            .Property(dt => dt.Penalidad)
            .HasDefaultValue(0m);

        // Configuración de relaciones

        // Usuario - Cliente (1 a 0/1)
        modelBuilder.Entity<Usuario>()
            .HasOne(u => u.Cliente)
            .WithOne(c => c.Usuario)
            .HasForeignKey<Cliente>(c => c.UsuarioId)
            .OnDelete(DeleteBehavior.Restrict);

        // Cliente - Ubigeo
        modelBuilder.Entity<Cliente>()
            .HasOne(c => c.Ubigeo)
            .WithMany()
            .HasForeignKey(c => c.UbigeoId)
            .OnDelete(DeleteBehavior.Restrict);

        // Libro - Categoria
        modelBuilder.Entity<Libro>()
            .HasOne(l => l.Categoria)
            .WithMany()
            .HasForeignKey(l => l.CategoriaId)
            .OnDelete(DeleteBehavior.Restrict);

        // Ejemplar - Libro
        modelBuilder.Entity<Ejemplar>()
            .HasOne(e => e.Libro)
            .WithMany(l => l.Ejemplares)
            .HasForeignKey(e => e.LibroId)
            .OnDelete(DeleteBehavior.Restrict);

        // Ejemplar - Estante
        modelBuilder.Entity<Ejemplar>()
            .HasOne(e => e.Estante)
            .WithMany()
            .HasForeignKey(e => e.EstanteId)
            .OnDelete(DeleteBehavior.Restrict);

        // Reserva - Cliente
        modelBuilder.Entity<Reserva>()
            .HasOne(r => r.Cliente)
            .WithMany(c => c.Reservas)
            .HasForeignKey(r => r.ClienteId)
            .OnDelete(DeleteBehavior.Restrict);

        // Reserva - UsuarioAprobador
        modelBuilder.Entity<Reserva>()
            .HasOne(r => r.UsuarioAprobador)
            .WithMany()
            .HasForeignKey(r => r.UsuarioAprobadorId)
            .OnDelete(DeleteBehavior.Restrict);

        // DetalleReserva - Reserva
        modelBuilder.Entity<DetalleReserva>()
            .HasOne(dr => dr.Reserva)
            .WithMany(r => r.Detalles)
            .HasForeignKey(dr => dr.ReservaId)
            .OnDelete(DeleteBehavior.Cascade);

        // Transaccion - Cliente
        modelBuilder.Entity<Transaccion>()
            .HasOne(t => t.Cliente)
            .WithMany(c => c.Transacciones)
            .HasForeignKey(t => t.ClienteId)
            .OnDelete(DeleteBehavior.Restrict);

        // Transaccion - Usuario
        modelBuilder.Entity<Transaccion>()
            .HasOne(t => t.Usuario)
            .WithMany()
            .HasForeignKey(t => t.UsuarioId)
            .OnDelete(DeleteBehavior.Restrict);

        // DetalleTransaccion - Transaccion
        modelBuilder.Entity<DetalleTransaccion>()
            .HasOne(dt => dt.Transaccion)
            .WithMany(t => t.Detalles)
            .HasForeignKey(dt => dt.TransaccionId)
            .OnDelete(DeleteBehavior.Cascade);

        // Notificacion - Cliente
        modelBuilder.Entity<Notificacion>()
            .HasOne(n => n.Cliente)
            .WithMany(c => c.Notificaciones)
            .HasForeignKey(n => n.ClienteId)
            .OnDelete(DeleteBehavior.Restrict);

        // Validaciones de tipo_item para DetalleReserva

        modelBuilder.Entity<DetalleReserva>(entity =>
        {
            entity.Property(e => e.TipoItem)
                .HasColumnName("TipoItem");

            entity.Property(e => e.LibroId)
                .HasColumnName("LibroId");

            entity.Property(e => e.ProductoId)
                .HasColumnName("ProductoId");
        });

        modelBuilder.Entity<DetalleReserva>()
              .HasCheckConstraint("CHK_DetalleReserva_TipoItem", "[TipoItem] IN ('libro', 'producto')");

        modelBuilder.Entity<DetalleReserva>()
            .HasCheckConstraint("CHK_DetalleReserva_Item",
                "([TipoItem] = 'libro' AND [LibroId] IS NOT NULL AND [ProductoId] IS NULL) OR " +
                "([TipoItem] = 'producto' AND [ProductoId] IS NOT NULL AND [LibroId] IS NULL)");

        // Corregir las restricciones CHECK para DetalleTransaccion
        modelBuilder.Entity<DetalleTransaccion>()
            .HasCheckConstraint("CHK_DetalleTransaccion_TipoItem", "[TipoItem] IN ('libro', 'producto')");

        modelBuilder.Entity<DetalleTransaccion>()
            .HasCheckConstraint("CHK_DetalleTransaccion_Item",
                "([TipoItem] = 'libro' AND [EjemplarId] IS NOT NULL AND [ProductoId] IS NULL) OR " +
                "([TipoItem] = 'producto' AND [ProductoId] IS NOT NULL AND [EjemplarId] IS NULL)");

        // Validaciones de tipo_item para DetalleTransaccion
        modelBuilder.Entity<DetalleTransaccion>()
            .HasCheckConstraint("CHK_DetalleTransaccion_TipoItem", "[tipo_item] IN ('libro', 'producto')");

        modelBuilder.Entity<DetalleTransaccion>()
            .HasCheckConstraint("CHK_DetalleTransaccion_Item",
                "([tipo_item] = 'libro' AND [ejemplar_id] IS NOT NULL AND [producto_id] IS NULL) OR " +
                "([tipo_item] = 'producto' AND [producto_id] IS NOT NULL AND [ejemplar_id] IS NULL)");
    }
}
