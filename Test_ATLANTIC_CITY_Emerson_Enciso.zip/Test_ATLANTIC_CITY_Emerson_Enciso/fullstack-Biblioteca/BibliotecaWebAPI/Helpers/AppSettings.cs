﻿namespace BibliotecaWebAPI.Helpers;

public class AppSettings
{
    public string Secret { get; set; }
}